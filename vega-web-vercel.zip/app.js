/* Pinturas y Decoraciones Vega · interacción (lo cargan todas las páginas)
   Se edita en fuente/ y `node fuente/generar.cjs` lo copia a web/. Sin dependencias. */
(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s), $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const root = document.documentElement;
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  root.classList.add('js');

  /* ───────── Medición sin cookies ─────────
     Cada elemento con data-track="tipo:lugar" cuenta como evento al pulsarlo. Solo hace algo si la
     página carga Plausible o GoatCounter (se activa en fuente/datos.cjs); sin ellos no sale nada de aquí.
     Tipos: whatsapp, llamada, cta (botones hacia el formulario), formulario (envío válido), resenas y mapa. */
  const NOMBRE = { whatsapp: 'WhatsApp', llamada: 'Llamada', cta: 'Pedir presupuesto', formulario: 'Formulario enviado', resenas: 'Reseñas de Google', mapa: 'Mapa' };
  if ($('script[data-medicion=plausible]') && !window.plausible) {
    /* Cola de Plausible: guarda los eventos hasta que termina de cargar su script */
    window.plausible = function () { (window.plausible.q = window.plausible.q || []).push(arguments); };
    window.plausible.init = window.plausible.init || function (o) { window.plausible.o = o || {}; };
    window.plausible.init();
  }
  const track = clave => {
    const [tipo, lugar = ''] = clave.split(':');
    const pagina = location.pathname.split('/').pop() || 'index.html';
    try {
      window.plausible?.(NOMBRE[tipo] || tipo, { props: { lugar, pagina } });
      window.goatcounter?.count?.({ path: `evento/${tipo}/${lugar}`, title: `${NOMBRE[tipo] || tipo} (${lugar})`, event: true });
    } catch { /* la medición nunca debe romper la web */ }
  };
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-track]');
    if (el) track(el.dataset.track);
  });

  /* ───────── Menú (móvil) y WhatsApp flotante ───────── */
  const bg = $('.burger'), nv = $('#nav'), wafab = $('#wafab');
  if (bg && nv) {
    const setMenu = (o, foco) => {
      nv.classList.toggle('open', o);
      bg.setAttribute('aria-expanded', o);
      bg.setAttribute('aria-label', o ? 'Cerrar menú' : 'Abrir menú');
      if (foco) bg.focus();
    };
    bg.addEventListener('click', () => setMenu(!nv.classList.contains('open')));
    nv.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
    addEventListener('keydown', e => { if (e.key === 'Escape' && nv.classList.contains('open')) setMenu(false, true); });
  }
  const hd = $('.hd-flota');
  if (wafab || hd) {
    /* El WhatsApp flotante aparece al dejar atrás el arranque; en la portada, la cabecera se vuelve sólida al bajar */
    const onScroll = () => { wafab?.classList.toggle('on', scrollY > innerHeight * .6); hd?.classList.toggle('s', scrollY > 24); };
    addEventListener('scroll', onScroll, { passive: true }); onScroll();
  }

  /* ───────── Hero: la escena 3D ─────────
     Es una escena real de three.js (escena.js, dentro de la propia web): sin imagen ni vídeo de respaldo. Se carga después
     de `load`, cuando el navegador está libre. En un equipo sin GPU es la misma escena, simplificada (calidad «baja»). Con
     «reducir movimiento» o ahorro de datos se dibuja una sola vez la composición final, también en 3D y sin animación.
     Si el navegador no tiene WebGL (o lo bloquea), la portada lo avisa y deja reintentar.
     El titular, el texto y los botones aparecen al acabar la entrada (la hoja de estilos los oculta hasta entonces solo
     si hay JavaScript y movimiento): cualquier fallo, la pausa o un tiempo máximo los muestran. */
  const h3d = $('#hero3d');
  if (h3d) {
    const hero = h3d.closest('.hero'), pausa = $('#pausa3d'), rotulo = $('#etapa');
    const reposo = calm || !!navigator.connection?.saveData;
    let lienzo = null, escena = null, aviso = null, reloj = 0;
    const mostrar = () => { clearTimeout(reloj); hero.classList.add('hero-listo'); };
    /* WebGL: null si no hay ninguno; si lo hay, dice si dibuja por software (sin GPU) */
    const webgl = () => {
      try {
        const c = document.createElement('canvas'), gl = c.getContext('webgl2') || c.getContext('webgl');
        if (!gl) return null;
        const info = gl.getExtension('WEBGL_debug_renderer_info');
        const nombre = String(info ? gl.getParameter(info.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return { software: /swiftshader|llvmpipe|softpipe|software|basic render/i.test(nombre) };
      } catch { return null; }
    };
    const quitar = () => {
      h3d.classList.remove('vivo');
      if (escena) escena.destruir();
      escena = null; window.__vega3d = null;
      if (lienzo) lienzo.parentNode?.removeChild(lienzo);
      lienzo = null; if (pausa) pausa.hidden = true;
    };
    const quitarAviso = () => { if (aviso) aviso.remove(); aviso = null; };
    /* Sin WebGL: se dice y se deja reintentar. No se sustituye por una imagen ni por un vídeo. */
    const fallar = (motivo = 'webgl') => {
      quitar(); quitarAviso(); mostrar();
      aviso = Object.assign(document.createElement('div'), { className: 'hero-aviso', role: 'alert' });
      const texto = Object.assign(document.createElement('p'), { textContent: {
        webgl: 'No se ha podido mostrar la escena en 3D: este navegador no tiene WebGL o lo tiene bloqueado.',
        archivo: 'La escena en 3D no se carga al abrir el archivo desde el disco: el navegador no deja. Abre la web desde un servidor (en local: node pruebas/servidor.cjs y http://localhost:8000).',
        carga: 'No se ha podido cargar o iniciar la escena en 3D. Pulsa Reintentar o recarga la página.',
      }[motivo] });
      const boton = Object.assign(document.createElement('button'), { type: 'button', textContent: 'Reintentar' });
      boton.addEventListener('click', () => iniciar());
      aviso.append(texto, boton); hero.append(aviso);
    };
    const iniciar = async () => {
      quitar(); quitarAviso();
      const gl = webgl();
      if (location.protocol === 'file:') return fallar('archivo');
      if (!gl) return fallar();
      try {
        const etapas = JSON.parse(h3d.dataset.etapas);
        const { crear } = await import(new URL(h3d.dataset.escena, document.baseURI).href);
        const modesto = matchMedia('(max-width: 900px), (pointer: coarse)').matches || (navigator.deviceMemory || 8) <= 4;
        const calidad = gl.software ? 'baja' : modesto ? 'media' : 'alta';
        lienzo = Object.assign(document.createElement('canvas'), { className: 'hero-lienzo' });
        lienzo.setAttribute('aria-hidden', 'true');
        h3d.append(lienzo);
        escena = crear(lienzo, {
          etapas, calidad, forzar: true, estatico: reposo,
          alCambiar: i => { if (rotulo) rotulo.textContent = etapas[i].nombre; },
          alPintar: () => h3d.classList.add('vivo'),
          alContenido: mostrar,
        });
        lienzo.addEventListener('vega3d-perdido', () => fallar());                // si el sistema retira la GPU
        window.__vega3d = escena;                                          // para las pruebas y las capturas
        if (reposo) mostrar();
        else {
          if (pausa) { pausa.hidden = false; pausa.setAttribute('aria-pressed', 'false'); pausa.textContent = 'Pausar animación'; }
          if (calidad === 'baja') mostrar();                               // sin GPU no se hace esperar al texto
          else reloj = setTimeout(mostrar, (escena.pre + 2) * 1000);
        }
      } catch (e) { console.warn('Escena 3D:', e); fallar('carga'); }
    };
    /* Botón de pausa (WCAG 2.2.2: toda animación que empieza sola debe poder pararse). Al pausar se muestra el texto. */
    if (pausa) pausa.addEventListener('click', () => {
      if (!escena) return;
      const parar = pausa.getAttribute('aria-pressed') !== 'true';
      pausa.setAttribute('aria-pressed', parar); pausa.textContent = parar ? 'Reanudar animación' : 'Pausar animación';
      escena.pausar(parar); if (parar) mostrar();
    });
    const cuandoPueda = () => ('requestIdleCallback' in window ? requestIdleCallback(iniciar, { timeout: 2500 }) : setTimeout(iniciar, 400));
    if (document.readyState === 'complete') cuandoPueda(); else addEventListener('load', cuandoPueda, { once: true });
  }

  /* ───────── Apariciones al llegar (una vez): titulares y fotos de la galería ───────── */
  const rvl = $$('.rvl, .rv');
  if (rvl.length) {
    const io = new IntersectionObserver(es => es.forEach(x => { if (x.isIntersecting) { x.target.classList.add('in'); io.unobserve(x.target); } }), { threshold: .12, rootMargin: '0px 0px -40px 0px' });
    rvl.forEach(el => io.observe(el));
  }
  /* Ampliar una foto (solo las que tienen versión grande: enlaces con data-zoom) */
  document.addEventListener('click', e => {
    const a = e.target.closest('a[data-zoom]');
    if (!a || !window.HTMLDialogElement) return;
    e.preventDefault();
    const d = document.createElement('dialog');
    d.className = 'zoom';
    d.setAttribute('aria-label', 'Foto ampliada');
    const cerrar = Object.assign(document.createElement('button'), { type: 'button', textContent: 'Cerrar' });
    const pic = document.createElement('picture');
    if (a.dataset.avif) pic.append(Object.assign(document.createElement('source'), { type: 'image/avif', srcset: a.dataset.avif }));
    const mini = $('img', a);
    const img = Object.assign(document.createElement('img'), { src: a.href, alt: mini ? mini.alt : '' });
    if (a.dataset.w) { img.width = a.dataset.w; img.height = a.dataset.h; }
    pic.append(img);
    const pieFoto = document.createElement('p');
    pieFoto.textContent = a.closest('figure')?.querySelector('figcaption b')?.textContent || '';
    d.append(cerrar, pic, pieFoto);
    cerrar.addEventListener('click', () => d.close());
    d.addEventListener('click', ev => { if (ev.target === d) d.close(); });      // clic fuera de la foto
    d.addEventListener('close', () => { d.remove(); a.focus(); });
    document.body.append(d);
    d.showModal();
  });

  /* ───────── Pared de la foto del hero ─────────
     Al elegir un color, la pared de la foto se pinta en 4 pasadas seguidas, de abajo arriba,
     encima del color anterior. --from = color que ya tiene, --to = color nuevo.
     El blanco (#FFFFFF) deja la foto como es, porque la capa se multiplica sobre ella. */
  const wallEl = $('#wall');
  if (wallEl) {
    const strokes = $$('.strokes i', wallEl);
    const ORIGINAL = '#FFFFFF';
    let wallShown = ORIGINAL, wallAnims = [];   // wallShown = último color pedido
    const wallCommit = c => {
      wallAnims.forEach(x => x.cancel()); wallAnims = [];
      wallEl.style.setProperty('--from', c);
    };
    const paintWall = c => {
      wallCommit(wallShown);                    // si había una pasada a medias, se termina al instante
      if (c === wallShown) return;
      wallShown = c;
      wallEl.style.setProperty('--to', c);
      if (calm) return wallCommit(c);
      const D = 420, step = D + 60;
      strokes.forEach((st, i) => wallAnims.push(st.animate([{ transform: 'scaleY(0)' }, { transform: 'scaleY(1)' }],
        { duration: D, delay: i * step, easing: 'cubic-bezier(.45,0,.25,1)', fill: 'forwards' })));
      const mine = wallAnims.slice();
      Promise.all(mine.map(x => x.finished)).then(() => { if (wallAnims[0] === mine[0]) wallCommit(c); }).catch(() => {});
    };

    /* Carta de colores: pinta la pared y tiñe el campo de color del hero.
       data-c = color, data-f = color del texto que va encima (contraste AA, viene de datos.cjs). */
    const chips = $$('.chips button');
    const cn = $('#cn'), cr = $('#cr');
    const paint = b => {
      chips.forEach(x => x.setAttribute('aria-pressed', x === b));
      root.style.setProperty('--wall', b.dataset.c);
      root.style.setProperty('--wall-fg', b.dataset.f);
      if (cn) cn.textContent = b.dataset.n;
      if (cr) cr.textContent = b.dataset.r;
      paintWall(b.dataset.c);
    };
    chips.forEach(b => b.addEventListener('click', () => paint(b)));

    /* Al entrar se ve la foto tal cual y, al segundo, la pared se pinta con el color de la carta */
    const first = $('.chips button[aria-pressed=true]')?.dataset.c || '#24435C';
    if (calm) { wallShown = first; wallCommit(first); }
    else { wallCommit(ORIGINAL); setTimeout(() => { if (wallShown === ORIGINAL) paintWall(first); }, 1200); }
  }

  /* ───────── Reseñas ───────── */
  /* «Leer más» en las tarjetas que no caben */
  $$('.rc').forEach(c => {
    const p = $('blockquote p', c);
    requestAnimationFrame(() => {
      if (p.scrollHeight > p.clientHeight + 2) {
        const b = Object.assign(document.createElement('button'), { type: 'button', className: 'more', textContent: 'Leer más' });
        b.setAttribute('aria-expanded', 'false');
        b.addEventListener('click', () => { const o = c.classList.toggle('open'); b.textContent = o ? 'Leer menos' : 'Leer más'; b.setAttribute('aria-expanded', o); });
        $('blockquote', c).append(b);
      }
    });
  });
  /* En móvil las reseñas son un carrusel: los puntos marcan la tarjeta visible */
  const rail = $('#rail'), dots = $('.rv-dots');
  if (rail && dots) {
    const cards = [...rail.children];
    const ds = cards.map(() => dots.appendChild(document.createElement('i')));
    const sync = () => {
      const step = cards[1] ? cards[1].offsetLeft - cards[0].offsetLeft : 1;
      const end = rail.scrollLeft + rail.clientWidth >= rail.scrollWidth - 4;
      const n = end ? cards.length - 1 : Math.min(cards.length - 1, Math.round(rail.scrollLeft / (step || 1)));
      ds.forEach((d, k) => d.classList.toggle('on', k === n));
    };
    rail.addEventListener('scroll', sync, { passive: true });
    addEventListener('resize', sync); sync();
  }

  /* ───────── Mapa: solo se conecta con Google cuando la persona lo pide ───────── */
  const mapa = $('#mapa'), mapBtn = $('#map-load');
  if (mapa && mapBtn) mapBtn.addEventListener('click', () => {
    const f = Object.assign(document.createElement('iframe'), { title: mapa.dataset.title, src: mapa.dataset.src });
    f.referrerPolicy = 'no-referrer-when-downgrade';
    f.tabIndex = 0;
    mapa.replaceChildren(f);
    mapa.classList.add('on');
    f.focus();
  });

  /* ───────── Formulario → WhatsApp ─────────
     No envía nada a ningún servidor: valida, compone el mensaje y abre wa.me.
     No pide teléfono: el mensaje sale del WhatsApp de la persona y ya trae su número. */
  const form = $('#f');
  if (form) {
    const opts = $('#k');
    form.noValidate = true;                     // validamos aquí, con mensajes propios (sin JS valida el navegador)
    /* Si se llega desde una página de servicio (index.html?t=gotele), el tipo de trabajo ya viene marcado */
    const t = new URLSearchParams(location.search).get('t');
    if (t) { const r = $$('input[name=k]', form).find(x => x.dataset.k === t); if (r) r.checked = true; }

    const setErr = (id, msg) => {
      const el = id === 'k' ? opts : $('#' + id);
      el.setAttribute('aria-invalid', msg ? 'true' : 'false');
      $('#e-' + id).textContent = msg || '';
    };
    ['n', 'p'].forEach(id => $('#' + id).addEventListener('input', () => setErr(id, '')));
    opts.addEventListener('change', () => setErr('k', ''));

    form.addEventListener('submit', e => {
      e.preventDefault();
      const n = form.n.value.trim(), m = form.text.value.trim();
      const k = $('input[name=k]:checked', form)?.value;
      const errs = {
        n: n.length < 2 ? 'Escribe tu nombre.' : '',
        k: !k ? 'Elige un tipo de trabajo.' : '',
        p: !form.p.checked ? 'Marca la casilla para aceptar la política de privacidad.' : '',
      };
      Object.entries(errs).forEach(([id, msg]) => setErr(id, msg));
      const first = Object.keys(errs).find(id => errs[id]);
      if (first) { (first === 'k' ? $('input', opts) : $('#' + first)).focus(); return; }

      const lines = [`Hola, soy ${n}. Quiero pedir presupuesto.`, `• Trabajo: ${k}`, m && `• Detalles: ${m}`].filter(Boolean);
      const url = `${form.action}?text=${encodeURIComponent(lines.join('\n'))}`;
      track('formulario:presupuesto');          // solo se cuenta cuando el formulario es válido
      const w = window.open(url, '_blank');
      if (w) w.opener = null;
      const ok = $('#ok');
      /* Se construye con nodos de texto: lo que escribe la persona nunca se interpreta como HTML */
      const again = Object.assign(document.createElement('a'), { href: url, target: '_blank', rel: 'noopener', textContent: 'Ábrelo aquí' });
      ok.replaceChildren(`Listo, ${n.split(' ')[0]}. Se ha abierto WhatsApp con tu solicitud: solo falta pulsar enviar. ¿No se abrió? `, again, '.');
      ok.hidden = false;
      if (!w) location.href = url;
    });
  }
})();
